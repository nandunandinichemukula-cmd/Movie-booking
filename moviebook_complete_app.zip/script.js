const movies=[
 {id:1,title:"Pushpa 2",rating:"8.2",genre:"Action • Drama • Thriller",poster:"posters/pushpa2.svg",desc:"An action-packed theatrical experience."},
 {id:2,title:"Jawan",rating:"7.1",genre:"Action • Thriller",poster:"posters/jawan.svg",desc:"A high-energy action entertainer."},
 {id:3,title:"Leo",rating:"7.8",genre:"Action • Thriller",poster:"posters/leo.svg",desc:"A stylish action thriller for the big screen."},
 {id:4,title:"Avengers Endgame",rating:"8.4",genre:"Action • Adventure • Sci-Fi",poster:"posters/avengers.svg",desc:"A superhero adventure movie night."}
];

const theatres=[
 {name:"PVR Cinemas",area:"Benz Circle",shows:["10:30 AM","01:30 PM","06:30 PM","09:45 PM"]},
 {name:"INOX",area:"LEPL Mall",shows:["11:00 AM","02:15 PM","05:45 PM","09:15 PM"]},
 {name:"Cinepolis",area:"PVP Square",shows:["10:15 AM","01:00 PM","04:30 PM","08:30 PM"]}
];

let selectedMovie=null, selectedTheatre=null, selectedShow=null, selectedSeats=[];
const price=150;
const grid=document.getElementById("movieGrid");

function renderMovies(list=movies){
 grid.innerHTML="";
 document.getElementById("movieCount").textContent=`${list.length} movies`;
 list.forEach(m=>{
  const card=document.createElement("article"); card.className="movie-card";
  card.innerHTML=`<div class="poster"><img src="${m.poster}" alt="${m.title} poster"></div>
  <h3>${m.title}</h3><p>⭐ ${m.rating} &nbsp; | &nbsp; ${m.genre}</p>
  <button class="book-btn">Book Now</button>`;
  card.querySelector("button").addEventListener("click",()=>startBooking(m));
  grid.appendChild(card);
 });
}

function startBooking(movie){
 selectedMovie=movie; selectedTheatre=null; selectedShow=null; selectedSeats=[];
 document.getElementById("chosenPoster").src=movie.poster;
 document.getElementById("chosenTitle").textContent=movie.title;
 document.getElementById("chosenMeta").textContent=`⭐ ${movie.rating} | ${movie.genre}`;
 document.getElementById("chosenDescription").textContent=movie.desc;
 document.getElementById("booking").classList.remove("hidden");
 renderTheatres(); renderSeats(); updateSummary();
 location.hash="booking";
}

function renderTheatres(){
 const box=document.getElementById("theatreList"); box.innerHTML="";
 theatres.forEach(t=>{
  const div=document.createElement("div"); div.className="theatre";
  div.innerHTML=`<div class="theatre-title">${t.name} <span>• ${t.area}</span></div>
  <div>${t.shows.map(s=>`<button class="show-btn" data-show="${s}">${s}</button>`).join("")}</div>`;
  div.querySelectorAll(".show-btn").forEach(btn=>btn.addEventListener("click",()=>{
   selectedTheatre=t; selectedShow=btn.dataset.show;
   document.querySelectorAll(".theatre").forEach(x=>x.classList.remove("selected"));
   div.classList.add("selected");
   div.querySelectorAll(".show-btn").forEach(x=>x.classList.remove("selected"));
   btn.classList.add("selected");
   updateSummary();
  }));
  box.appendChild(div);
 });
}

function renderSeats(){
 const box=document.getElementById("seatLayout"); box.innerHTML="";
 for(let i=1;i<=60;i++){
  const s=document.createElement("button"); s.className="seat"; s.textContent=i;
  if([7,8,19,20,41,42,55].includes(i)){s.classList.add("booked");s.disabled=true}
  s.addEventListener("click",()=>{
   if(s.classList.contains("selected")){
    s.classList.remove("selected"); selectedSeats=selectedSeats.filter(x=>x!==i);
   }else{
    if(selectedSeats.length>=8){alert("You can select up to 8 seats.");return}
    s.classList.add("selected"); selectedSeats.push(i);
   }
   updateSummary();
  });
  box.appendChild(s);
 }
}

function updateSummary(){
 const total=selectedSeats.length*price;
 document.getElementById("summary").innerHTML=`
 <div class="summary-row"><span>Movie</span><b>${selectedMovie?.title||"-"}</b></div>
 <div class="summary-row"><span>Theatre</span><b>${selectedTheatre?.name||"-"}</b></div>
 <div class="summary-row"><span>Show</span><b>${selectedShow||"-"}</b></div>
 <div class="summary-row"><span>Seats</span><b>${selectedSeats.length?selectedSeats.join(", "):"-"}</b></div>
 <div class="summary-row total"><span>Total</span><b>₹${total}</b></div>`;
}

document.getElementById("search").addEventListener("input",e=>{
 const q=e.target.value.toLowerCase();
 renderMovies(movies.filter(m=>m.title.toLowerCase().includes(q)||m.genre.toLowerCase().includes(q)));
});

document.getElementById("confirmBtn").addEventListener("click",()=>{
 const name=document.getElementById("customerName").value.trim();
 const mobile=document.getElementById("mobile").value.trim();
 const payment=document.getElementById("payment").value;
 if(!selectedMovie||!selectedTheatre||!selectedShow||selectedSeats.length===0||!name||mobile.length!==10||!payment){
  alert("Please complete movie, theatre/show, seats, customer and payment details.");
  return;
 }
 const bookingId="MB"+Date.now().toString().slice(-8);
 document.getElementById("confirmationText").textContent=`Thank you, ${name}. Your booking is confirmed.`;
 document.getElementById("ticket").innerHTML=`
 <b>${selectedMovie.title}</b><br>
 ${selectedTheatre.name}, ${selectedTheatre.area}<br>
 ${selectedShow} • 28 Sep 2026<br>
 Seats: ${selectedSeats.join(", ")}<br>
 Total: ₹${selectedSeats.length*price}<br>
 Booking ID: <b>${bookingId}</b>`;
 document.getElementById("confirmation").classList.remove("hidden");
 setTimeout(()=>{try{window.close()}catch(e){}},4000);
});

document.getElementById("closeBtn").addEventListener("click",()=>{
 try{window.close()}catch(e){}
 alert("Booking completed. Your browser may block closing a normal tab.");
});

renderMovies();
